var page = undefined;
// const backgroundAudioManager = wx.getBackgroundAudioManager()

// backgroundAudioManager.title = '往后余生';
// backgroundAudioManager.epname = '往后余生';
// backgroundAudioManager.singer = 'yumiao';
// backgroundAudioManager.coverImgUrl = 'http://y.gtimg.cn/music/photo_new/T002R300x300M000003rsKF44GyaSk.jpg?max_age=2592000';
// backgroundAudioManager.src = 'https://www.imchenlei.com/wanghouyusheng.mp3'; // 设置了 src 之后会自动播放 
Page({
    onLoad: function () {
        page = this;
        this.bindbt();
        // wx.playVoice({
        //     filePath: 'https://www.imchenlei.com/wanghouyusheng.mp3'
        // })
        // wx.playBackgroundAudio({
        //     dataUrl: './../../utils/wanghouyusheng.mp3'
        // })
    },
    bindbt: function () {
        let arr = ["hello chenlei","传奇，我喜欢你","好开心呀~","橙子，我想你了","你在干嘛","你可以帮我洗个东西吗？","我宣你","好像一直和你在一起","今天心情好好","你请我喝了一杯我最爱喝的奶茶耶","你就是我的唯一","这周日你有空吗？","有空有空","来日方长"]
        for(let i = 0;i<arr.length;i++){
            doommList.push(new Doomm(arr[i], Math.ceil(Math.random() * 100), Math.ceil(Math.random() * 30), getRandomColor()));
        }
        this.setData({
            doommData: doommList
        })
        console.log(doommList);
    },
    pauseMusic:function(){
        wx.pauseBackgroundAudio();
    },
    data: {
        doommData: []
    }
})
var doommList = [];
var i = 0;//用做唯一的wx:key
class Doomm {
    constructor(text, top, time, color) {
        this.text = text;
        this.top = top;
        this.time = time;
        this.color = color;
        this.display = true;
        let that = this;
        this.id = i++;
        setTimeout(function () {
            doommList.splice(doommList.indexOf(that), 1);//动画完成，从列表中移除这项
            page.setData({
                doommData: doommList
            })
        }, this.time * 1000)//定时器动画完成后执行。
    }
}
function getRandomColor() {
    let rgb = []
    for (let i = 0; i < 3; ++i) {
        let color = Math.floor(Math.random() * 256).toString(16)
        color = color.length == 1 ? '0' + color : color
        rgb.push(color)
    }
    return '#' + rgb.join('')
}