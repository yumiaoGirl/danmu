var page = undefined;
Page({
    data: {
        stopMusicFlag:false,
        rotateIndex: '',
        animationData: {},
        doommData: [],
        userInfo:{},
        inputTxt:"",
        canIUse: wx.canIUse('button.open-type.getUserInfo'),
        danArr: ["Hi 你好吗", "我可以每天都能看见你嘛？", "我想我们能永远在一起", "往后余生都是你", "往事匆匆", "你总是会感动"],
        radomDanArr:["对你第一印像超好","回眸一笑百媚生","放屁大王","独立自信","呀，这什么造型"]
    },
    // 生命周期函数--监听页面加载
    onLoad: function (options) {
        page = this;
        var that = this;
        wx.getStorage({
            key: 'danmuArr',
            success: function (res) {
                console.log(res.data);
                if(res.data){
                    that.setData({
                        danArr: res.data
                    })
                }else{
                    wx.setStorage({
                        key: "danmuArr",
                        data: this.data.danArr
                    })
                }
                
            }
        });
        wx.getUserInfo({
            success: function (res) {
                that.setData({
                    userInfo: res.userInfo
                })
                console.log(that.data.userInfo);
            }
        })
        this.playMusic();
        this.bindbt(this.data.danArr);
        wx.onBackgroundAudioStop(function(){
            that.playMusic();
        });
    },
    bindGetUserInfo: function (e) {
        console.log(e.detail.userInfo)
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        // 创建动画
        var animation = wx.createAnimation({
            duration: 2000,
            timingFunction: "linear"
        })
        this.animation = animation
        // 执行旋转或者点击图片旋转(如果你想要点击就在图片上添加点击事件我默认是添加的)
        this.refreshList();
    },
    onHide: function () {
        wx.stopBackgroundAudio();
    },
    /**
     * 当页面销毁时调用
     */
    onUnload: function () {
        wx.stopBackgroundAudio()
    },
    txtInput:function(e){
        this.setData({
            inputTxt: e.detail.value
        })
    },
    sendTxt:function(){
        console.log(this.data.inputTxt);
        this.bindSig(this.data.inputTxt);
        this.data.danArr.push(this.data.inputTxt);
        wx.setStorage({
            key: "danmuArr",
            data: this.data.danArr
        })
        this.setData({
            inputTxt:""
        })
    },
    clickBox:function(e){
        console.log(e.currentTarget.dataset.index);
        let item = e.currentTarget.dataset.index;
        this.bindSig(item);
        this.data.danArr.push(item);
        wx.setStorage({
            key: "danmuArr",
            data: this.data.danArr
        })
    },
    bindSig: function (txt) {
        console.log(txt);
        doommList.push(new Doomm(txt, Math.ceil(Math.random() * 100), Math.ceil(Math.random() * 30), getRandomColor()));
        this.setData({
            doommData: doommList
        })
    },
    bindbt: function (arr) {
        console.log(arr);
        for (let i = 0; i < arr.length; i++) {
            doommList.push(new Doomm(arr[i], Math.ceil(Math.random() * 100), Math.ceil(Math.random() * 30), getRandomColor()));
        }
        this.setData({
            doommData: doommList
        })
    },
    refreshList: function () {//旋转图片
        var n = 0;
        //连续动画需要添加定时器,所传参数每次+1就行
        this.timeInterval = setInterval(function () {
            n = n+1;
            this.data.rotateIndex = this.data.rotateIndex + 1;
            this.animation.rotate(180 * n).step()
            this.setData({
                animationData: this.animation.export()
            })
        }.bind(this), 500)
    },
    stopRefresh: function () {//停止旋转
        if (this.timeInterval > 0) {
            clearInterval(this.timeInterval)
            this.timeInterval = 0
        }
    },
    playMusic: function(){//播放音乐
        wx.playBackgroundAudio({
            dataUrl: 'https://www.imchenlei.com/wanghouyusheng.mp3',
            title: '往后余生',
        })
    },
    stopMusic: function(){//停止播放
        let that = this;
        if (that.data.stopMusicFlag){
            that.playMusic();
        }else{
            that.setData({
                stopMusicFlag : true
            })
            wx.pauseBackgroundAudio();
            that.stopRefresh();
        }
    }
})
var doommList = [];
var i = 0;//用做唯一的wx:key
class Doomm {
    constructor(text, top, time, color) {
        this.text = text;
        this.top = top;
        this.time = time;
        this.color = color;
        this.display = true;
        let that = this;
        this.id = i++;
        setTimeout(function () {
            doommList.splice(doommList.indexOf(that), 1);//动画完成，从列表中移除这项
            page.setData({
                doommData: doommList
            })
        }, this.time * 1000)//定时器动画完成后执行。
    }
}
function getRandomColor() {
    let rgb = []
    for (let i = 0; i < 3; ++i) {
        let color = Math.floor(Math.random() * 256).toString(16)
        color = color.length == 1 ? '0' + color : color
        rgb.push(color)
    }
    return '#' + rgb.join('')
}